########################## set #########################################

dis2 = {'kumar', 'hari', 'raj'}

print dis2

dis2.add('tj')
print dis2

dis2.add('hari')
print dis2

dis2.remove('kumar')
print dis2

dis2.append('hari') # AttributeError: 'set' object has no attribute 'append'

print dis2[0] # TypeError: 'set' object does not support indexing


A = [1,3,2,4]
B = [2,4,7,8]

print set(A) - set(B) # A - set([1, 3])
print set(A) & set(B) # C - set([2, 4])
print set(B) - set(A) # B - set([8, 7])
print set(A) # A + C - set([1, 2, 3, 4])
print set(B) # B + C - set([8, 2, 4, 7])
print set(A) ^ set(B) # A + B - set([1, 3, 7, 8])
print set(A) | set(B) # A + B + C - set([1, 2, 3, 4, 7, 8])
